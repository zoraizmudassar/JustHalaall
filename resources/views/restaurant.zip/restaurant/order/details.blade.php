@extends('restaurant.layouts.app')
@section('title','Pending Orders')
@section('content')
    @include('component.restaurantOrderDetails')
@endsection
